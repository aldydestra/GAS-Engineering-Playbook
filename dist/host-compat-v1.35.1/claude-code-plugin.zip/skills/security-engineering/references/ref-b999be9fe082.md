<!-- Generated from skills/07-security-engineering/SKILL.md -->
# References

## Official — Google Apps Script

- Authorization for Google Services  
  https://developers.google.com/apps-script/guides/services/authorization

- Web Apps  
  https://developers.google.com/apps-script/guides/web

- Installable Triggers  
  https://developers.google.com/apps-script/guides/triggers/installable

- Session  
  https://developers.google.com/apps-script/reference/base/session

- Properties Service  
  https://developers.google.com/apps-script/guides/properties

- OAuth scopes  
  https://developers.google.com/identity/protocols/oauth2/scopes

- OAuth policies  
  https://developers.google.com/identity/protocols/oauth2/policies

## Official — Google Cloud

- Secret Manager best practices  
  https://cloud.google.com/secret-manager/docs/best-practices

- Secret Manager IAM access control  
  https://cloud.google.com/secret-manager/docs/access-control

## Security Reference

- OWASP Authorization Cheat Sheet  
  https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html

- OWASP Input Validation Cheat Sheet  
  https://cheatsheetseries.owasp.org/cheatsheets/Input_Validation_Cheat_Sheet.html

- OWASP Web Service Security Cheat Sheet  
  https://cheatsheetseries.owasp.org/cheatsheets/Web_Service_Security_Cheat_Sheet.html

- OWASP Secure Code Review Cheat Sheet  
  https://cheatsheetseries.owasp.org/cheatsheets/Secure_Code_Review_Cheat_Sheet.html

## Community / Forum Signals

- Stack Overflow — blank `Session.getActiveUser()` behavior  
  https://stackoverflow.com/questions/15651781/google-script-session-getactiveuser-getemail-not-working

- Stack Overflow — Session identity discussion  
  https://stackoverflow.com/questions/59029142/get-session-from-google-script-blank

- r/GoogleAppsScript — web app deployment/access discussions  
  https://www.reddit.com/r/GoogleAppsScript/

Community sources are used to identify recurring confusion and operational edge cases. Current official documentation defines current Apps Script behavior.

---
