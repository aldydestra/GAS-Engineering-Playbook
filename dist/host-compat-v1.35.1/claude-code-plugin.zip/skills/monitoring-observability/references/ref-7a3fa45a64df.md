<!-- Generated from skills/09-monitoring-observability/SKILL.md -->
# References

## Official — Google Apps Script

- Logging / Cloud Logging / Error Reporting  
  https://developers.google.com/apps-script/guides/logging

- Apps Script dashboard  
  https://developers.google.com/apps-script/guides/dashboard

- Troubleshooting / Executions  
  https://developers.google.com/apps-script/guides/support/troubleshooting

- `Logger`  
  https://developers.google.com/apps-script/reference/base/logger

- `console`  
  https://developers.google.com/apps-script/reference/base/console

- `Session`  
  https://developers.google.com/apps-script/reference/base/session

- Google Cloud projects for Apps Script  
  https://developers.google.com/apps-script/guides/cloud-platform-projects

## Community Signals

- Stack Overflow — Google Apps Script logging/monitoring discussions  
  https://stackoverflow.com/questions/tagged/google-apps-script+logging

- r/GoogleAppsScript  
  https://www.reddit.com/r/GoogleAppsScript/

Community sources are used to discover operational pain points. Current Google documentation and reproducible execution behavior define Apps Script logging semantics.

## Operational Burn-In Evidence Gate (v1.31)

For migration or release-candidate burn-in, treat observations as an append-only operational evidence stream rather than a manually edited summary.

- bind every observation to a timestamp, channel, consumer alias, summary, and durable evidence reference;
- use a hash chain when the journal is part of a release gate;
- require a minimum observation window and minimum sessions per channel before declaring PASS;
- distinguish `IN_PROGRESS` from `FAIL`: insufficient exposure is not a defect, while a blocking incident is;
- recompute the aggregate from the journal during verification so a hand-edited summary cannot authorize promotion.

## Unified Operational Release Closure (v1.34)

When live burn-in is a release gate, correlate operational observations with the exact release candidate that will be published. Preserve the burn-in journal, lifecycle evidence, release-subject inventory digest, tag, publication timestamp, and post-publication verification outcome as one traceable evidence chain.

Do not collapse these states:

```text
IN_PROGRESS / NOT_RUN → insufficient operational exposure
FAIL → observed blocking defect
READY_FOR_CEREMONY → live gate and approval complete, publication not yet closed
PASS → immutable release and asset verification completed for the same candidate
```

A release ceremony is an operational event. Monitor it like one: record retries, external dependency failures, permission blockers, immutable-release policy state, and verification results without reclassifying infrastructure blockers as product defects.

---
