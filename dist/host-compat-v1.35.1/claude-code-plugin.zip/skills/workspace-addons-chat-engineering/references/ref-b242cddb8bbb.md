<!-- Generated from skills/14-workspace-addons-chat-engineering/SKILL.md -->
# References

## Official Google Workspace Add-ons

- Overview  
  https://developers.google.com/workspace/add-ons

- Build Google Workspace add-ons  
  https://developers.google.com/workspace/add-ons/how-tos/building-workspace-addons

- Card-based interfaces  
  https://developers.google.com/workspace/add-ons/concepts/card-interfaces

- Workspace add-on triggers  
  https://developers.google.com/workspace/add-ons/concepts/workspace-triggers

- Workspace add-on manifests  
  https://developers.google.com/workspace/add-ons/concepts/workspace-manifests

- Universal actions  
  https://developers.google.com/workspace/add-ons/how-tos/universal-actions

## Apps Script

- Card Service  
  https://developers.google.com/apps-script/reference/card-service

- AddOns Response Service  
  https://developers.google.com/apps-script/reference/add-ons-response-service

- AddOns manifest resource  
  https://developers.google.com/apps-script/manifest/addons

- Apps Script release notes  
  https://developers.google.com/apps-script/release-notes

## Google Chat / AI Integration

- Build Chat interfaces  
  https://developers.google.com/workspace/add-ons/chat/build

- Chat app with Apps Script  
  https://developers.google.com/workspace/add-ons/chat/quickstart-apps-script

- ADK agent quickstart  
  https://developers.google.com/workspace/add-ons/chat/quickstart-adk-agent

- A2A agent quickstart  
  https://developers.google.com/workspace/add-ons/chat/quickstart-a2a-agent

- A2UI agent quickstart  
  https://developers.google.com/workspace/add-ons/chat/quickstart-a2ui-agent

---
