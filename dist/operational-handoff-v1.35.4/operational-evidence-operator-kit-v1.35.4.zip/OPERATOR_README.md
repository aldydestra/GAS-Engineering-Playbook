# Portable Operational Evidence Operator Kit — v1.35.4

This kit is candidate-bound. Before extraction, compare the **whole ZIP SHA-256** against the authoritative `dist/operational-handoff-*/SHA256SUMS` transferred through the trusted release channel. The verifier inside the archive is not the authenticity root for the archive that contains it.

After the outer digest matches, extract the kit, preserve its directory structure, and run the trusted verifier against the original ZIP if it is still available:

```bash
python3 tools/verify_operator_kit.py operational-evidence-operator-kit-v1.35.4.zip
```

Then prove the external runtime against the frozen candidate before any lifecycle evidence is accepted:

```bash
python3 tools/preflight_operational_environment.py --allow-npx-bootstrap --probe-host
python3 tools/run_live_host_smoke.py --host gemini-cli --npx-bootstrap
python3 tools/record_burn_in.py record --channel canonical --consumer <alias> --summary <summary> --evidence-ref <ref>
python3 tools/record_burn_in.py record --channel package --consumer <alias> --summary <summary> --evidence-ref <ref>
python3 tools/record_burn_in.py finalize
python3 tools/collect_operational_evidence.py
```

Do not create promotion approval or publish a release from the portable kit. Import the resulting evidence bundle into the authoritative repository, rebuild live validation, then perform approval/release ceremony there.
